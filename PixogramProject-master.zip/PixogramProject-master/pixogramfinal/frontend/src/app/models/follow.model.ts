export class FollowModel {
    constructor(
        public myid: Number,
        public userid: Number
    ){
    }
    
  }
  
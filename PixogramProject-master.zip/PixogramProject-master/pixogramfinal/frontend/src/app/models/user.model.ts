export class UserModel{
    public id:Number;
    constructor(
            public fname:String,
            public lname:String,
            public username:String,
            public password:String,
            public email:String,
      
            public profilepic:String
    ){}
}

/* public dob:String, */
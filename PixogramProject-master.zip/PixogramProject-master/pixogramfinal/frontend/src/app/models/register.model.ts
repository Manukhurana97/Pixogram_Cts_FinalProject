export class Login{
    constructor(
        public userName1: string,
        public password:string
    ){}
}
export class UpdateModel {

    constructor(

        public username: String,
        public password: String,
        public email: String,

    ) { }
}

/* public dob:String, */
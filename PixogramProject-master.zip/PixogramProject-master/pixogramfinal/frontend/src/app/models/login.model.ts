export interface LoginModel {
  id: string;
  username: string;
  password: String;
  profilepic: string;
}
